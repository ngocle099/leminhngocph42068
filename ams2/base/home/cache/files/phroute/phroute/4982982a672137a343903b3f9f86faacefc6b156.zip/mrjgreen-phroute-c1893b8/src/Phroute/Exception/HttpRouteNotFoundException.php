<?php namespace Phroute\Phroute\Exception;

class HttpRouteNotFoundException extends HttpException {}

