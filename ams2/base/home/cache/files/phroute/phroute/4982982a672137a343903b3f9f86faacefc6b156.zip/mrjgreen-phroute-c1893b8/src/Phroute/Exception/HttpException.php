<?php namespace Phroute\Phroute\Exception;

class HttpException extends \Exception {}
