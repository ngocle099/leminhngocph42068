<?php namespace Phroute\Phroute\Exception;

class HttpMethodNotAllowedException extends HttpException {}
