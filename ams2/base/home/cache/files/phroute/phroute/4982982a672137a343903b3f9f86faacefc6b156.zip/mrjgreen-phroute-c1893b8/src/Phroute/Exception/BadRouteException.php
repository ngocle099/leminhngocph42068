<?php namespace Phroute\Phroute\Exception;

class BadRouteException extends \LogicException {
}
