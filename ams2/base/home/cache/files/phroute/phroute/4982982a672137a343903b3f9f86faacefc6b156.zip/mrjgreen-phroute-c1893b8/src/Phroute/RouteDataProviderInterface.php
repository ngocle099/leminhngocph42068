<?php namespace Phroute\Phroute;


/**
 * Interface RouteDataProviderInterface
 * @package Phroute\Phroute
 */
interface RouteDataProviderInterface {

    /**
     * @return mixed
     */
    public function getData();
}
